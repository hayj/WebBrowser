pip uninstall systemtools
python setup.py install
